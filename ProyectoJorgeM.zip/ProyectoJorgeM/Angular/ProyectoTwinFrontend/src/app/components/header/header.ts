import { Component } from '@angular/core';

@Component({
  selector: 'tw-header',
  standalone: false,
  templateUrl: './header.html',
  styleUrl: './header.css'
})
export class Header {

}
