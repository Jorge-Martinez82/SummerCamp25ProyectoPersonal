import { Component } from '@angular/core';

@Component({
  selector: 'tw-footer',
  standalone: false,
  templateUrl: './footer.html',
  styleUrl: './footer.css'
})
export class Footer {

}
